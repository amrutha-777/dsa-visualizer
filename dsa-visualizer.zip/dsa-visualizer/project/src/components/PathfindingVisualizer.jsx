import React, { useState, useEffect, useRef } from 'react';
import { bfs, dfs, createGridWithPath } from '../utils/pathfinding';

const PathfindingVisualizer = () => {
  const [grid, setGrid] = useState([]);
  const [isAnimating, setIsAnimating] = useState(false);
  const [algorithm, setAlgorithm] = useState('bfs');
  const [speed, setSpeed] = useState(50);
  const [startNode, setStartNode] = useState({ row: 5, col: 5 });
  const [endNode, setEndNode] = useState({ row: 5, col: 15 });
  const [visitedNodes, setVisitedNodes] = useState(0);
  const [pathLength, setPathLength] = useState(0);
  const animationRef = useRef(null);

  const ROWS = 15;
  const COLS = 25;

  useEffect(() => {
    resetGrid();
  }, []);

  const resetGrid = () => {
    if (isAnimating) return;
    const newGrid = createGridWithPath(ROWS, COLS, startNode, endNode);
    setGrid(newGrid);
    setVisitedNodes(0);
    setPathLength(0);
    
    // Reset visual state
    const cells = document.querySelectorAll('.grid-cell');
    cells.forEach(cell => {
      cell.classList.remove('visited', 'path', 'current');
    });
  };

  const startPathfinding = async () => {
    if (isAnimating) return;
    
    setIsAnimating(true);
    setVisitedNodes(0);
    setPathLength(0);
    
    // Clear previous visualization
    const cells = document.querySelectorAll('.grid-cell');
    cells.forEach(cell => {
      cell.classList.remove('visited', 'path', 'current');
    });
    
    let result;
    if (algorithm === 'bfs') {
      result = bfs(grid, startNode, endNode);
    } else if (algorithm === 'dfs') {
      result = dfs(grid, startNode, endNode);
    }
    
    if (result) {
      await animatePathfinding(result.visitedInOrder, result.path);
    }
    
    setIsAnimating(false);
  };

  const animatePathfinding = (visitedInOrder, path) => {
    return new Promise((resolve) => {
      let visitedIndex = 0;
      
      const animateVisited = () => {
        if (visitedIndex >= visitedInOrder.length) {
          // Start path animation
          animatePath(path, resolve);
          return;
        }
        
        const node = visitedInOrder[visitedIndex];
        const cell = document.querySelector(`[data-row="${node.row}"][data-col="${node.col}"]`);
        
        if (cell && !cell.classList.contains('start') && !cell.classList.contains('end')) {
          cell.classList.add('visited');
          setVisitedNodes(prev => prev + 1);
        }
        
        visitedIndex++;
        animationRef.current = setTimeout(animateVisited, speed);
      };
      
      const animatePath = (path, callback) => {
        if (!path || path.length === 0) {
          callback();
          return;
        }
        
        let pathIndex = 0;
        setPathLength(path.length);
        
        const animatePathStep = () => {
          if (pathIndex >= path.length) {
            callback();
            return;
          }
          
          const node = path[pathIndex];
          const cell = document.querySelector(`[data-row="${node.row}"][data-col="${node.col}"]`);
          
          if (cell && !cell.classList.contains('start') && !cell.classList.contains('end')) {
            cell.classList.add('path');
          }
          
          pathIndex++;
          setTimeout(animatePathStep, speed / 2);
        };
        
        animatePathStep();
      };
      
      animateVisited();
    });
  };

  const stopAnimation = () => {
    if (animationRef.current) {
      clearTimeout(animationRef.current);
      animationRef.current = null;
    }
    setIsAnimating(false);
  };

  const clearPath = () => {
    if (isAnimating) return;
    
    const cells = document.querySelectorAll('.grid-cell');
    cells.forEach(cell => {
      cell.classList.remove('visited', 'path', 'current');
    });
    
    setVisitedNodes(0);
    setPathLength(0);
  };

  const getCellClass = (cell) => {
    let className = 'grid-cell';
    if (cell.isWall) className += ' wall';
    if (cell.isStart) className += ' start';
    if (cell.isEnd) className += ' end';
    return className;
  };

  return (
    <div className="pathfinding-container">
      <div className="card">
        <div className="controls-container">
          <div className="controls-group">
            <label className="form-label">Algorithm</label>
            <select 
              value={algorithm} 
              onChange={(e) => setAlgorithm(e.target.value)}
              className="form-control form-select"
              disabled={isAnimating}
            >
              <option value="bfs">Breadth-First Search</option>
              <option value="dfs">Depth-First Search</option>
            </select>
          </div>
          
          <div className="controls-group">
            <label className="form-label">Speed: {speed}ms</label>
            <input
              type="range"
              min="10"
              max="200"
              value={speed}
              onChange={(e) => setSpeed(parseInt(e.target.value))}
              className="form-range"
              disabled={isAnimating}
            />
          </div>
          
          <div className="controls-buttons">
            <button 
              onClick={startPathfinding}
              disabled={isAnimating}
              className="btn btn-primary"
            >
              {isAnimating ? 'Finding Path...' : 'Start Pathfinding'}
            </button>
            <button 
              onClick={stopAnimation}
              disabled={!isAnimating}
              className="btn btn-danger"
            >
              Stop
            </button>
            <button 
              onClick={clearPath}
              disabled={isAnimating}
              className="btn btn-secondary"
            >
              Clear Path
            </button>
            <button 
              onClick={resetGrid}
              disabled={isAnimating}
              className="btn btn-outline"
            >
              Reset Grid
            </button>
          </div>
        </div>
        
        <div className="stats-container">
          <div className="stat-item">
            <div className="stat-label">Visited Nodes</div>
            <div className="stat-value">{visitedNodes}</div>
          </div>
          <div className="stat-item">
            <div className="stat-label">Path Length</div>
            <div className="stat-value">{pathLength}</div>
          </div>
        </div>
        
        <div className="legend">
          <div className="legend-item">
            <div className="legend-color" style={{ backgroundColor: '#10b981' }}></div>
            <span>Start</span>
          </div>
          <div className="legend-item">
            <div className="legend-color" style={{ backgroundColor: '#ef4444' }}></div>
            <span>End</span>
          </div>
          <div className="legend-item">
            <div className="legend-color" style={{ backgroundColor: '#374151' }}></div>
            <span>Wall</span>
          </div>
          <div className="legend-item">
            <div className="legend-color" style={{ backgroundColor: '#93c5fd' }}></div>
            <span>Visited</span>
          </div>
          <div className="legend-item">
            <div className="legend-color" style={{ backgroundColor: '#fbbf24' }}></div>
            <span>Path</span>
          </div>
        </div>
      </div>
      
      <div className="card">
        <div className="grid-container">
          <div className="pathfinding-grid">
            {grid.map((row, rowIndex) =>
              row.map((cell, colIndex) => (
                <div
                  key={`${rowIndex}-${colIndex}`}
                  className={getCellClass(cell)}
                  data-row={rowIndex}
                  data-col={colIndex}
                />
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PathfindingVisualizer;