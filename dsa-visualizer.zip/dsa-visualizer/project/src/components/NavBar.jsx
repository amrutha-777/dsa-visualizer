import React from 'react';

const NavBar = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'sorting', label: 'Sorting', icon: '📊' },
    { id: 'pathfinding', label: 'Pathfinding', icon: '🗺️' },
    { id: 'trees', label: 'Trees', icon: '🌳' },
  ];

  return (
    <nav className="nav-container">
      <div className="nav-tabs">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`nav-tab ${activeTab === tab.id ? 'active' : ''}`}
          >
            <span className="nav-tab-icon">{tab.icon}</span>
            <span className="nav-tab-label">{tab.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
};

export default NavBar;