import React, { useState, useEffect } from 'react';
import { createTreeFromArray, inorderTraversal, preorderTraversal, postorderTraversal } from '../utils/tree';

const TreeVisualizer = () => {
  const [inputArray, setInputArray] = useState('4,2,6,1,3,5,7');
  const [tree, setTree] = useState(null);
  const [traversalType, setTraversalType] = useState('inorder');
  const [traversalResult, setTraversalResult] = useState([]);
  const [isAnimating, setIsAnimating] = useState(false);
  const [currentNode, setCurrentNode] = useState(null);
  const [visitedNodes, setVisitedNodes] = useState(new Set());

  useEffect(() => {
    buildTree();
  }, []);

  const buildTree = () => {
    try {
      const array = inputArray.split(',').map(val => {
        const num = parseInt(val.trim());
        return isNaN(num) ? null : num;
      }).filter(val => val !== null);
      
      if (array.length === 0) {
        setTree(null);
        return;
      }
      
      const newTree = createTreeFromArray(array);
      setTree(newTree);
      setTraversalResult([]);
      setCurrentNode(null);
      setVisitedNodes(new Set());
    } catch (error) {
      console.error('Error building tree:', error);
    }
  };

  const startTraversal = async () => {
    if (!tree || isAnimating) return;
    
    setIsAnimating(true);
    setTraversalResult([]);
    setCurrentNode(null);
    setVisitedNodes(new Set());
    
    let traversalOrder;
    if (traversalType === 'inorder') {
      traversalOrder = inorderTraversal(tree);
    } else if (traversalType === 'preorder') {
      traversalOrder = preorderTraversal(tree);
    } else if (traversalType === 'postorder') {
      traversalOrder = postorderTraversal(tree);
    }
    
    await animateTraversal(traversalOrder);
    setIsAnimating(false);
  };

  const animateTraversal = (traversalOrder) => {
    return new Promise((resolve) => {
      let index = 0;
      
      const animate = () => {
        if (index >= traversalOrder.length) {
          setCurrentNode(null);
          resolve();
          return;
        }
        
        const node = traversalOrder[index];
        setCurrentNode(node);
        
        setTimeout(() => {
          setVisitedNodes(prev => new Set([...prev, node]));
          setTraversalResult(prev => [...prev, node]);
          setCurrentNode(null);
          index++;
          animate();
        }, 800);
      };
      
      animate();
    });
  };

  const resetTraversal = () => {
    setTraversalResult([]);
    setCurrentNode(null);
    setVisitedNodes(new Set());
  };

  const renderTreeNode = (node, level = 0, position = 'center') => {
    if (!node) return null;
    
    const isHighlighted = currentNode === node.value;
    const isVisited = visitedNodes.has(node.value);
    
    return (
      <div key={`${node.value}-${level}-${position}`} className="tree-node">
        <div className={`tree-node-circle ${isHighlighted ? 'highlighted' : ''} ${isVisited ? 'visited' : ''}`}>
          {node.value}
        </div>
        {(node.left || node.right) && (
          <div className="tree-branches">
            <div className="tree-level">
              {node.left && renderTreeNode(node.left, level + 1, 'left')}
              {node.right && renderTreeNode(node.right, level + 1, 'right')}
            </div>
          </div>
        )}
      </div>
    );
  };

  const renderTree = () => {
    if (!tree) return <div className="text-center">No tree to display</div>;
    
    return (
      <div className="tree-visualization">
        {renderTreeNode(tree)}
      </div>
    );
  };

  return (
    <div className="tree-container">
      <div className="card">
        <div className="controls-container">
          <div className="tree-input-container">
            <div className="controls-group">
              <label className="form-label">Array Input (comma-separated)</label>
              <input
                type="text"
                value={inputArray}
                onChange={(e) => setInputArray(e.target.value)}
                className="form-control"
                placeholder="4,2,6,1,3,5,7"
                disabled={isAnimating}
              />
            </div>
            
            <button 
              onClick={buildTree}
              disabled={isAnimating}
              className="btn btn-outline"
            >
              Build Tree
            </button>
          </div>
          
          <div className="controls-group">
            <label className="form-label">Traversal Type</label>
            <select 
              value={traversalType} 
              onChange={(e) => setTraversalType(e.target.value)}
              className="form-control form-select"
              disabled={isAnimating}
            >
              <option value="inorder">In-order (Left → Root → Right)</option>
              <option value="preorder">Pre-order (Root → Left → Right)</option>
              <option value="postorder">Post-order (Left → Right → Root)</option>
            </select>
          </div>
          
          <div className="controls-buttons">
            <button 
              onClick={startTraversal}
              disabled={!tree || isAnimating}
              className="btn btn-primary"
            >
              {isAnimating ? 'Traversing...' : 'Start Traversal'}
            </button>
            <button 
              onClick={resetTraversal}
              disabled={isAnimating}
              className="btn btn-secondary"
            >
              Reset Traversal
            </button>
          </div>
        </div>
        
        {traversalResult.length > 0 && (
          <div className="traversal-result">
            <div className="traversal-label">
              {traversalType.charAt(0).toUpperCase() + traversalType.slice(1)} Traversal Result:
            </div>
            <div className="traversal-sequence">
              {traversalResult.join(' → ')}
            </div>
          </div>
        )}
      </div>
      
      <div className="card">
        {renderTree()}
      </div>
    </div>
  );
};

export default TreeVisualizer;