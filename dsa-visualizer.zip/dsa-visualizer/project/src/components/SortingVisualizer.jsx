import React, { useState, useEffect, useRef } from 'react';
import { bubbleSort, mergeSort, parseNumberInput } from '../utils/sorting';

const SortingVisualizer = () => {
  const [inputNumbers, setInputNumbers] = useState('64,34,25,12,22,11,90');
  const [array, setArray] = useState([]);
  const [isAnimating, setIsAnimating] = useState(false);
  const [algorithm, setAlgorithm] = useState('bubble');
  const [speed, setSpeed] = useState(500);
  const [comparisons, setComparisons] = useState(0);
  const [swaps, setSwaps] = useState(0);
  const [currentComparing, setCurrentComparing] = useState([]);
  const [currentSwapping, setCurrentSwapping] = useState([]);
  const animationRef = useRef(null);

  useEffect(() => {
    parseInput();
  }, []);

  const parseInput = () => {
    if (isAnimating) return;
    const newArray = parseNumberInput(inputNumbers);
    setArray(newArray);
    setComparisons(0);
    setSwaps(0);
    setCurrentComparing([]);
    setCurrentSwapping([]);
  };

  const generateRandomArray = () => {
    if (isAnimating) return;
    const randomNumbers = [];
    for (let i = 0; i < 8; i++) {
      randomNumbers.push(Math.floor(Math.random() * 99) + 1);
    }
    const newInput = randomNumbers.join(',');
    setInputNumbers(newInput);
    setArray(randomNumbers);
    setComparisons(0);
    setSwaps(0);
    setCurrentComparing([]);
    setCurrentSwapping([]);
  };

  const startAnimation = async () => {
    if (isAnimating || array.length === 0) return;
    
    setIsAnimating(true);
    setComparisons(0);
    setSwaps(0);
    setCurrentComparing([]);
    setCurrentSwapping([]);
    
    let animations;
    if (algorithm === 'bubble') {
      animations = bubbleSort([...array]);
    } else if (algorithm === 'merge') {
      animations = mergeSort([...array]);
    }
    
    await animateArray(animations);
    
    // Final animation - highlight all numbers as sorted
    setCurrentComparing([]);
    setCurrentSwapping([]);
    
    setIsAnimating(false);
  };

  const animateArray = (animations) => {
    return new Promise((resolve) => {
      let animationIndex = 0;
      const currentArray = [...array];
      
      const animate = () => {
        if (animationIndex >= animations.length) {
          resolve();
          return;
        }
        
        const animation = animations[animationIndex];
        const { type, indices, newArray } = animation;
        
        if (type === 'compare') {
          const [i, j] = indices;
          setCurrentComparing([i, j]);
          setCurrentSwapping([]);
          setComparisons(prev => prev + 1);
        } else if (type === 'swap') {
          const [i, j] = indices;
          setCurrentSwapping([i, j]);
          setCurrentComparing([]);
          setSwaps(prev => prev + 1);
          
          // Perform the swap in our display array
          const temp = currentArray[i];
          currentArray[i] = currentArray[j];
          currentArray[j] = temp;
          setArray([...currentArray]);
        } else if (type === 'update') {
          // For merge sort - update the entire array
          if (newArray) {
            setArray([...newArray]);
            setCurrentComparing([]);
            setCurrentSwapping([]);
          }
        }
        
        animationIndex++;
        animationRef.current = setTimeout(animate, speed);
      };
      
      animate();
    });
  };

  const stopAnimation = () => {
    if (animationRef.current) {
      clearTimeout(animationRef.current);
      animationRef.current = null;
    }
    setIsAnimating(false);
    setCurrentComparing([]);
    setCurrentSwapping([]);
  };

  const getNumberClass = (index) => {
    let className = 'number-item';
    if (currentComparing.includes(index)) {
      className += ' comparing';
    } else if (currentSwapping.includes(index)) {
      className += ' swapping';
    }
    return className;
  };

  return (
    <div className="card">
      <div className="controls-container">
        <div className="controls-group">
          <label className="form-label">Numbers (comma-separated)</label>
          <input
            type="text"
            value={inputNumbers}
            onChange={(e) => setInputNumbers(e.target.value)}
            className="form-control"
            placeholder="64,34,25,12,22,11,90"
            disabled={isAnimating}
          />
          <button 
            onClick={parseInput}
            disabled={isAnimating}
            className="btn btn-outline"
          >
            Parse Numbers
          </button>
        </div>
        
        <div className="controls-group">
          <label className="form-label">Algorithm</label>
          <select 
            value={algorithm} 
            onChange={(e) => setAlgorithm(e.target.value)}
            className="form-control form-select"
            disabled={isAnimating}
          >
            <option value="bubble">Bubble Sort</option>
            <option value="merge">Merge Sort</option>
          </select>
        </div>
        
        <div className="controls-group">
          <label className="form-label">Speed: {speed}ms</label>
          <input
            type="range"
            min="100"
            max="2000"
            value={speed}
            onChange={(e) => setSpeed(parseInt(e.target.value))}
            className="form-range"
            disabled={isAnimating}
          />
        </div>
        
        <div className="controls-buttons">
          <button 
            onClick={startAnimation}
            disabled={isAnimating || array.length === 0}
            className="btn btn-primary"
          >
            {isAnimating ? 'Sorting...' : 'Start Sort'}
          </button>
          <button 
            onClick={stopAnimation}
            disabled={!isAnimating}
            className="btn btn-danger"
          >
            Stop
          </button>
          <button 
            onClick={generateRandomArray}
            disabled={isAnimating}
            className="btn btn-secondary"
          >
            Random Numbers
          </button>
        </div>
      </div>
      
      <div className="stats-container">
        <div className="stat-item">
          <div className="stat-label">Comparisons</div>
          <div className="stat-value">{comparisons}</div>
        </div>
        <div className="stat-item">
          <div className="stat-label">Swaps</div>
          <div className="stat-value">{swaps}</div>
        </div>
      </div>
      
      <div className="sorting-container">
        <div className="numbers-display">
          {array.map((number, index) => (
            <div
              key={`${number}-${index}`}
              className={getNumberClass(index)}
            >
              {number}
            </div>
          ))}
        </div>
        
        {array.length === 0 && (
          <div className="empty-state">
            Enter numbers above and click "Parse Numbers" to begin
          </div>
        )}
      </div>
    </div>
  );
};

export default SortingVisualizer;