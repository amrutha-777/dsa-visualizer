// Pathfinding algorithms with closed figure path

export const createGridWithPath = (rows, cols, startNode, endNode) => {
  const grid = [];
  for (let row = 0; row < rows; row++) {
    const currentRow = [];
    for (let col = 0; col < cols; col++) {
      currentRow.push({
        row,
        col,
        isStart: row === startNode.row && col === startNode.col,
        isEnd: row === endNode.row && col === endNode.col,
        isWall: false,
        isVisited: false,
        distance: Infinity,
        previousNode: null
      });
    }
    grid.push(currentRow);
  }
  
  // Create a closed figure path (rectangular maze)
  createClosedFigure(grid, rows, cols);
  
  return grid;
};

const createClosedFigure = (grid, rows, cols) => {
  // Create outer walls
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      // Top and bottom walls
      if (row === 0 || row === rows - 1) {
        grid[row][col].isWall = true;
      }
      // Left and right walls
      if (col === 0 || col === cols - 1) {
        grid[row][col].isWall = true;
      }
    }
  }
  
  // Create inner rectangular obstacles
  const centerRow = Math.floor(rows / 2);
  const centerCol = Math.floor(cols / 2);
  
  // Create a rectangular obstacle in the center
  for (let row = centerRow - 2; row <= centerRow + 2; row++) {
    for (let col = centerCol - 4; col <= centerCol + 4; col++) {
      if (row >= 0 && row < rows && col >= 0 && col < cols) {
        // Create hollow rectangle
        if (row === centerRow - 2 || row === centerRow + 2 || 
            col === centerCol - 4 || col === centerCol + 4) {
          grid[row][col].isWall = true;
        }
      }
    }
  }
  
  // Create some additional obstacles to make it interesting
  // Left side obstacle
  for (let row = 3; row <= 6; row++) {
    for (let col = 3; col <= 5; col++) {
      if (row < rows && col < cols) {
        grid[row][col].isWall = true;
      }
    }
  }
  
  // Right side obstacle
  for (let row = 8; row <= 11; row++) {
    for (let col = cols - 6; col <= cols - 4; col++) {
      if (row < rows && col >= 0 && col < cols) {
        grid[row][col].isWall = true;
      }
    }
  }
  
  // Ensure start and end nodes are not walls
  grid[5][5].isWall = false;
  grid[5][15].isWall = false;
};

export const getNeighbors = (grid, node) => {
  const neighbors = [];
  const { row, col } = node;
  
  // Up
  if (row > 0) neighbors.push(grid[row - 1][col]);
  // Down
  if (row < grid.length - 1) neighbors.push(grid[row + 1][col]);
  // Left
  if (col > 0) neighbors.push(grid[row][col - 1]);
  // Right
  if (col < grid[0].length - 1) neighbors.push(grid[row][col + 1]);
  
  return neighbors.filter(neighbor => !neighbor.isWall);
};

export const bfs = (grid, startNode, endNode) => {
  const visitedNodesInOrder = [];
  const queue = [];
  
  const startGridNode = grid[startNode.row][startNode.col];
  const endGridNode = grid[endNode.row][endNode.col];
  
  startGridNode.distance = 0;
  queue.push(startGridNode);
  
  while (queue.length > 0) {
    const currentNode = queue.shift();
    
    if (currentNode.isWall) continue;
    if (currentNode.isVisited) continue;
    
    currentNode.isVisited = true;
    visitedNodesInOrder.push(currentNode);
    
    if (currentNode === endGridNode) {
      return {
        visitedInOrder: visitedNodesInOrder,
        path: getPath(endGridNode)
      };
    }
    
    const neighbors = getNeighbors(grid, currentNode);
    for (const neighbor of neighbors) {
      if (!neighbor.isVisited && !neighbor.isWall) {
        neighbor.distance = currentNode.distance + 1;
        neighbor.previousNode = currentNode;
        queue.push(neighbor);
      }
    }
  }
  
  return {
    visitedInOrder: visitedNodesInOrder,
    path: []
  };
};

export const dfs = (grid, startNode, endNode) => {
  const visitedNodesInOrder = [];
  const stack = [];
  
  const startGridNode = grid[startNode.row][startNode.col];
  const endGridNode = grid[endNode.row][endNode.col];
  
  stack.push(startGridNode);
  
  while (stack.length > 0) {
    const currentNode = stack.pop();
    
    if (currentNode.isWall) continue;
    if (currentNode.isVisited) continue;
    
    currentNode.isVisited = true;
    visitedNodesInOrder.push(currentNode);
    
    if (currentNode === endGridNode) {
      return {
        visitedInOrder: visitedNodesInOrder,
        path: getPath(endGridNode)
      };
    }
    
    const neighbors = getNeighbors(grid, currentNode);
    for (const neighbor of neighbors) {
      if (!neighbor.isVisited && !neighbor.isWall) {
        neighbor.previousNode = currentNode;
        stack.push(neighbor);
      }
    }
  }
  
  return {
    visitedInOrder: visitedNodesInOrder,
    path: []
  };
};

const getPath = (endNode) => {
  const path = [];
  let currentNode = endNode;
  
  while (currentNode !== null) {
    path.unshift(currentNode);
    currentNode = currentNode.previousNode;
  }
  
  return path;
};