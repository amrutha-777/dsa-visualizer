// Sorting algorithms with animation data for numbers

export const parseNumberInput = (input) => {
  try {
    return input
      .split(',')
      .map(num => parseInt(num.trim()))
      .filter(num => !isNaN(num) && num >= 0);
  } catch (error) {
    return [];
  }
};

export const generateRandomArray = (size) => {
  const array = [];
  for (let i = 0; i < size; i++) {
    array.push(Math.floor(Math.random() * 99) + 1);
  }
  return array;
};

export const bubbleSort = (array) => {
  const animations = [];
  const n = array.length;
  
  for (let i = 0; i < n - 1; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      // Compare animation
      animations.push({
        type: 'compare',
        indices: [j, j + 1]
      });
      
      if (array[j] > array[j + 1]) {
        // Swap animation
        animations.push({
          type: 'swap',
          indices: [j, j + 1]
        });
        
        // Perform the swap
        const temp = array[j];
        array[j] = array[j + 1];
        array[j + 1] = temp;
      }
    }
  }
  
  return animations;
};

export const mergeSort = (array) => {
  const animations = [];
  const auxiliaryArray = array.slice();
  
  const mergeSortHelper = (mainArray, startIdx, endIdx, auxiliaryArray) => {
    if (startIdx === endIdx) return;
    
    const middleIdx = Math.floor((startIdx + endIdx) / 2);
    mergeSortHelper(auxiliaryArray, startIdx, middleIdx, mainArray);
    mergeSortHelper(auxiliaryArray, middleIdx + 1, endIdx, mainArray);
    doMerge(mainArray, startIdx, middleIdx, endIdx, auxiliaryArray);
  };
  
  const doMerge = (mainArray, startIdx, middleIdx, endIdx, auxiliaryArray) => {
    let k = startIdx;
    let i = startIdx;
    let j = middleIdx + 1;
    
    while (i <= middleIdx && j <= endIdx) {
      animations.push({
        type: 'compare',
        indices: [i, j]
      });
      
      if (auxiliaryArray[i] <= auxiliaryArray[j]) {
        mainArray[k] = auxiliaryArray[i];
        animations.push({
          type: 'update',
          indices: [k, i],
          newArray: [...mainArray]
        });
        i++;
      } else {
        mainArray[k] = auxiliaryArray[j];
        animations.push({
          type: 'update',
          indices: [k, j],
          newArray: [...mainArray]
        });
        j++;
      }
      k++;
    }
    
    while (i <= middleIdx) {
      mainArray[k] = auxiliaryArray[i];
      animations.push({
        type: 'update',
        indices: [k, i],
        newArray: [...mainArray]
      });
      i++;
      k++;
    }
    
    while (j <= endIdx) {
      mainArray[k] = auxiliaryArray[j];
      animations.push({
        type: 'update',
        indices: [k, j],
        newArray: [...mainArray]
      });
      j++;
      k++;
    }
  };
  
  mergeSortHelper(array, 0, array.length - 1, auxiliaryArray);
  return animations;
};