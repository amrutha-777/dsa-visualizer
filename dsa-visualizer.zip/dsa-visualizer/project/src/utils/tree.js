// Tree data structure and traversal algorithms

class TreeNode {
  constructor(value) {
    this.value = value;
    this.left = null;
    this.right = null;
  }
}

export const createTreeFromArray = (array) => {
  if (array.length === 0) return null;
  
  // Sort array to create a balanced BST
  const sortedArray = [...array].sort((a, b) => a - b);
  
  const buildTree = (arr, start, end) => {
    if (start > end) return null;
    
    const mid = Math.floor((start + end) / 2);
    const node = new TreeNode(arr[mid]);
    
    node.left = buildTree(arr, start, mid - 1);
    node.right = buildTree(arr, mid + 1, end);
    
    return node;
  };
  
  return buildTree(sortedArray, 0, sortedArray.length - 1);
};

export const inorderTraversal = (root) => {
  const result = [];
  
  const traverse = (node) => {
    if (node !== null) {
      traverse(node.left);
      result.push(node.value);
      traverse(node.right);
    }
  };
  
  traverse(root);
  return result;
};

export const preorderTraversal = (root) => {
  const result = [];
  
  const traverse = (node) => {
    if (node !== null) {
      result.push(node.value);
      traverse(node.left);
      traverse(node.right);
    }
  };
  
  traverse(root);
  return result;
};

export const postorderTraversal = (root) => {
  const result = [];
  
  const traverse = (node) => {
    if (node !== null) {
      traverse(node.left);
      traverse(node.right);
      result.push(node.value);
    }
  };
  
  traverse(root);
  return result;
};