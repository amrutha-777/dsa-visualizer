import React, { useState } from 'react';
import NavBar from './components/NavBar';
import SortingVisualizer from './components/SortingVisualizer';
import PathfindingVisualizer from './components/PathfindingVisualizer';
import TreeVisualizer from './components/TreeVisualizer';

function App() {
  const [activeTab, setActiveTab] = useState('sorting');

  const renderActiveComponent = () => {
    switch (activeTab) {
      case 'sorting':
        return <SortingVisualizer />;
      case 'pathfinding':
        return <PathfindingVisualizer />;
      case 'trees':
        return <TreeVisualizer />;
      default:
        return <SortingVisualizer />;
    }
  };

  return (
    <div className="main-container">
      <div className="container">
        <div className="text-center mb-4">
          <h1 className="main-title">DSA Visualizer</h1>
          <p className="main-subtitle">
            Interactive visualization of data structures and algorithms. 
            Watch how different algorithms work step by step.
          </p>
        </div>
        
        <NavBar activeTab={activeTab} onTabChange={setActiveTab} />
        
        <div className="content-area">
          {renderActiveComponent()}
        </div>
      </div>
    </div>
  );
}

export default App;